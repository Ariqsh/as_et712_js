let i=0; //counter variable

for (i; i<10; i++) { //starting point; condition; step 
 saySomething();
} 

function saySomething() {
    document.write("hello" + "<br>");//
}